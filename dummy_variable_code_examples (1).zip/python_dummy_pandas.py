import pandas as pd

data = {
    'Name': ['Ram', 'Shyam', 'Sita', 'Gita'],
    'Gender': ['Male', 'Male', 'Female', 'Female']
}

df = pd.DataFrame(data)

# Create dummy variables
dummy = pd.get_dummies(df['Gender'])

print(dummy)