#include <stdio.h>

int main() {
    int isStudent = 1;  // Dummy variable (1 = Yes, 0 = No)

    if(isStudent == 1)
        printf("Discount Applied");
    else
        printf("No Discount");

    return 0;
}