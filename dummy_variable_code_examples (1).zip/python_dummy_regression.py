import pandas as pd

data = {
    'Gender': ['Male', 'Female', 'Female', 'Male'],
    'Salary': [50000, 60000, 65000, 52000]
}

df = pd.DataFrame(data)

df['Gender_dummy'] = df['Gender'].map({'Male': 0, 'Female': 1})

print(df)